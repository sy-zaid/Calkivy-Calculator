package org.test.calkivy;

/* renamed from: org.test.calkivy.R */
public final class C0000R {

    /* renamed from: org.test.calkivy.R$drawable */
    public static final class drawable {
        public static final int ic_launcher = 2130771968;
        public static final int presplash = 2130771969;

        private drawable() {
        }
    }

    /* renamed from: org.test.calkivy.R$id */
    public static final class C0001id {
        public static final int author = 2130837504;
        public static final int emptyText = 2130837505;
        public static final int icon = 2130837506;
        public static final int projectList = 2130837507;
        public static final int title = 2130837508;

        private C0001id() {
        }
    }

    /* renamed from: org.test.calkivy.R$layout */
    public static final class layout {
        public static final int chooser_item = 2130903040;
        public static final int main = 2130903041;
        public static final int project_chooser = 2130903042;
        public static final int project_empty = 2130903043;

        private layout() {
        }
    }

    /* renamed from: org.test.calkivy.R$mipmap */
    public static final class mipmap {
        public static final int icon = 2130968576;

        private mipmap() {
        }
    }

    /* renamed from: org.test.calkivy.R$string */
    public static final class string {
        public static final int app_name = 2131034112;
        public static final int presplash_color = 2131034113;
        public static final int private_version = 2131034114;
        public static final int urlScheme = 2131034115;

        private string() {
        }
    }

    private C0000R() {
    }
}
