package org.test.calkivy;

public final class BuildConfig {
    public static final String APPLICATION_ID = "org.test.calkivy";
    public static final String BUILD_TYPE = "debug";
    public static final boolean DEBUG = Boolean.parseBoolean("true");
    public static final int VERSION_CODE = 10211;
    public static final String VERSION_NAME = "0.1";
}
