package org.libsdl.app;

import android.view.MotionEvent;

/* compiled from: SDLControllerManager */
class SDLJoystickHandler {
    SDLJoystickHandler() {
    }

    public boolean handleMotionEvent(MotionEvent event) {
        return false;
    }

    public void pollInputDevices() {
    }
}
